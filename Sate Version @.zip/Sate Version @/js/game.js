import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// Game variables
let camera, scene, renderer;
let player, ground;
let obstacles = [];
let score = 0;
let gameOver = false;

// Initialize the game
function init() {
    // Create scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);

    // Create camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 5, 10);

    // Create renderer
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.getElementById('game-container').appendChild(renderer.domElement);

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.6);
    directionalLight.position.set(10, 20, 0);
    scene.add(directionalLight);

    // Create ground
    const groundGeometry = new THREE.BoxGeometry(20, 1, 50);
    const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x1ec503 });
    ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.position.y = -0.5;
    scene.add(ground);

    // Create player
    const playerGeometry = new THREE.BoxGeometry(1, 1, 1);
    const playerMaterial = new THREE.MeshStandardMaterial({ color: 0xff0000 });
    player = new THREE.Mesh(playerGeometry, playerMaterial);
    player.position.y = 0.5;
    scene.add(player);

    // Add event listeners
    document.addEventListener('keydown', onKeyDown);
    window.addEventListener('resize', onWindowResize);

    // Start game loop
    animate();
    spawnObstacles();
}

// Handle keyboard input
function onKeyDown(event) {
    if (gameOver) return;

    const speed = 0.5;
    switch (event.key) {
        case 'ArrowLeft':
            if (player.position.x > -8) {
                player.position.x -= speed;
            }
            break;
        case 'ArrowRight':
            if (player.position.x < 8) {
                player.position.x += speed;
            }
            break;
        case ' ': // Spacebar
            if (player.position.y <= 0.5) {
                jump();
            }
            break;
    }
}

// Make the player jump
function jump() {
    const jumpForce = 0.15;
    const jumpInterval = setInterval(() => {
        if (player.position.y < 2) {
            player.position.y += jumpForce;
        } else {
            clearInterval(jumpInterval);
            fall();
        }
    }, 10);
}

// Make the player fall
function fall() {
    const fallInterval = setInterval(() => {
        if (player.position.y > 0.5) {
            player.position.y -= 0.1;
        } else {
            player.position.y = 0.5;
            clearInterval(fallInterval);
        }
    }, 10);
}

// Spawn obstacles
function spawnObstacles() {
    if (gameOver) return;

    const obstacleGeometry = new THREE.BoxGeometry(1, 1, 1);
    const obstacleMaterial = new THREE.MeshStandardMaterial({ color: 0x0000ff });
    const obstacle = new THREE.Mesh(obstacleGeometry, obstacleMaterial);
    
    obstacle.position.x = Math.random() * 16 - 8;
    obstacle.position.y = 0.5;
    obstacle.position.z = -20;
    
    scene.add(obstacle);
    obstacles.push(obstacle);

    setTimeout(spawnObstacles, 2000);
}

// Update obstacles
function updateObstacles() {
    const speed = 0.15;
    for (let i = obstacles.length - 1; i >= 0; i--) {
        const obstacle = obstacles[i];
        obstacle.position.z += speed;

        // Check collision
        if (checkCollision(player, obstacle)) {
            endGame();
        }

        // Remove obstacles that pass the player
        if (obstacle.position.z > 10) {
            scene.remove(obstacle);
            obstacles.splice(i, 1);
            updateScore();
        }
    }
}

// Check collision between two objects
function checkCollision(obj1, obj2) {
    const distance = obj1.position.distanceTo(obj2.position);
    return distance < 1;
}

// Update score
function updateScore() {
    score++;
    document.getElementById('score-value').textContent = score;
}

// End game
function endGame() {
    gameOver = true;
    alert(`Game Over! Your score: ${score}`);
}

// Handle window resize
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// Animation loop
function animate() {
    requestAnimationFrame(animate);
    if (!gameOver) {
        updateObstacles();
    }
    renderer.render(scene, camera);
}

// Start the game
init();